﻿using System;

namespace SteamKeyGen
{
	// Token: 0x02000009 RID: 9
	internal class SaveFileDialog
	{
		// Token: 0x06000011 RID: 17 RVA: 0x0000231A File Offset: 0x0000051A
		internal void ShowDialog()
		{
			throw new NotImplementedException();
		}
	}
}
