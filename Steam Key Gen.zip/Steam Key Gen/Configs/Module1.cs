﻿using System;
using System.IO;
using Microsoft.VisualBasic.CompilerServices;

namespace SteamKeyGen
{
	// Token: 0x02000008 RID: 8
	[StandardModule]
	internal sealed class Module1
	{
		// Token: 0x0600000F RID: 15 RVA: 0x000021B4 File Offset: 0x000003B4
		[STAThread]
		public static void Main()
		{
			Console.ForegroundColor = ConsoleColor.Green;
			Console.WriteLine("Bienvenido a Steam Key Generator!");
			Console.ForegroundColor = ConsoleColor.Magenta;
			Console.WriteLine("[Discord] Panda.xyz#0001");
			Console.ForegroundColor = ConsoleColor.Blue;
			Console.WriteLine("[GitHub] https://github.com/Pandaxyz-xd");
			Console.WriteLine("");
			Console.ForegroundColor = ConsoleColor.Red;
			Console.WriteLine("[SKG] ¿Cuantos Códigos Quieres Generar? :");
			int num = Conversions.ToInteger(Console.ReadLine());
			string folderPath = Environment.GetFolderPath(Environment.SpecialFolder.DesktopDirectory);
			FileStream stream = new FileStream(folderPath + "\\" + Conversions.ToString(num) + " Steam Keys.txt", FileMode.Create);
			TextWriter @out = Console.Out;
			StreamWriter streamWriter = new StreamWriter(stream);
			Console.SetOut(streamWriter);
			RandomKeyGenerator randomKeyGenerator = new RandomKeyGenerator();
			randomKeyGenerator.KeyLetters = "ABCDEFGHIJKLMNOPQRSTUVWYZ";
			randomKeyGenerator.KeyNumbers = "0123456789";
			randomKeyGenerator.KeyChars = 5;
			int num2 = num;
			checked
			{
				for (int i = 1; i <= num2; i++)
				{
					string text = randomKeyGenerator.Generate();
					Console.WriteLine(string.Concat(new string[]
					{
						randomKeyGenerator.Generate(),
						"-",
						randomKeyGenerator.Generate(),
						"-",
						randomKeyGenerator.Generate()
					}));
				}
				Console.SetOut(@out);
				streamWriter.Close();
				Console.Clear();
				Console.ForegroundColor = ConsoleColor.Green;
				Console.WriteLine(Conversions.ToString(num) + " Las Keys se han generado Exitosamente! Ruta: Escritorio");
				Console.ForegroundColor = ConsoleColor.Yellow;
				Console.WriteLine("Usa la tecla ENTER para salir...");
				Console.Read();
			}
		}
	}
}
